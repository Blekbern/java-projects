package cz.cvut.fel.pjv;

import java.util.Scanner;

public class Lab01 {
   
   public void start(String[] args) {
     
   }
}