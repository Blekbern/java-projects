
package pjv.hodina10;


public interface Stack {
    
    public void add(String word);
    public String pop() throws InterruptedException;
    public boolean isEmpty();
}
