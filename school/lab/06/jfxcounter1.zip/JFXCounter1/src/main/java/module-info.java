module cz.cvut.fel.pjv {
    requires javafx.controls;
    exports cz.cvut.fel.pjv;
}