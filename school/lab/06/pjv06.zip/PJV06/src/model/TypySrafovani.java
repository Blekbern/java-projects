package model;

/**
 *
 * @author Balik
 */
public enum TypySrafovani {
    NIC, VODOROVNEPRUHY, SVISLEPRUHY,PLNE;
}
